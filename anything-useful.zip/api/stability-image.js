export default function handler(req, res) {
  res.status(200).json({ message: "این یک نمونه API برای تولید تصویر است." });
}
